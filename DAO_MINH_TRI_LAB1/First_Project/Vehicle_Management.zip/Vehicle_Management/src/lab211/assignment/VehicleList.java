package lab211.assignment;

import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * This is comment, do not delete 2021.11.30
 * and open the template in the editor.
 */
/**
 *
 * @author Hoa Doan
 */

public class VehicleList extends ArrayList<Object> implements I_List {


}
